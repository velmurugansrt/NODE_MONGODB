'use strict';
var express = require('express');
var router = express.Router();
var login = require('./login.js');
var signup = require('./signup.js');
// var customer = require('./customer.js');
  

router.post('/signup', signup.request);
router.post('/login', login.request);
router.post('/profile', login.request);
// router.post('/customer', customer.request);

module.exports = router;