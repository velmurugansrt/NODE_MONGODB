'use strict';

var utils = {
	setmydb:function(){
		return 'mongodb://localhost/TODO';
	}
}
module.exports = utils;