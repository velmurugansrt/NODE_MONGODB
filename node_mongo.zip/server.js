'use strict';
var express = require('express');
var app = express();
const path = require('path');
var bodyParser = require('body-parser');
var routes = require('./server/');

app.use(bodyParser.json());
app.use(routes);

// app.post('/',function(req,res){
//   var result = {"response_code":"1","message":"enter valid data","result":req.body};
//   res.json(result); 
// })

var server = app.listen(9000, function () {
    console.log('Node server is running..');
});



