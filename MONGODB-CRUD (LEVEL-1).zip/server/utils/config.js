'use strict';

var utils = {
	setmydb:function(){
		return 'mongodb://localhost/todo';
	}
}
module.exports = utils;